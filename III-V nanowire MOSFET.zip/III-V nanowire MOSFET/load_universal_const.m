function [] = load_universal_const()
%%% load unversal constant
%%% all unit are S.I

%%
m0=9.1e-31;
K=1.38e-23;
eV=1.6e-19;
qe=1.6e-19;
eps0=8.854e-12;
h=6.62e-34;
hcut=h/(2*pi);

%%
save uni_const.mat
end

